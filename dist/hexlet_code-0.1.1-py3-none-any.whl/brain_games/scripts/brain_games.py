#!/usr/bin/env python3

# file <brain_games.py>
from brain_games.cli import *

def main():
    print('Welcome to the Brain Games!')
    welcome_user()


if __name__ == '__main__':
    main()
